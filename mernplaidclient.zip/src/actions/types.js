//will grab form error out of state, 
//name, email...wrong input
export const GET_ERRORS = "GET_ERRORS";
export const CLEAR_ERRORS = 'CLEAR_ERRORS'

//user login in, there mgith some delay, take some time
export const USER_LOADING = "USER_LOADING";

//put current login user info in the state
export const SET_CURRENT_USER = "SET_CURRENT_USER"; 

export const ADD_ACCOUNT = "ADD_ACCOUNT";
export const DELETE_ACCOUNT = "DELETE_ACCOUNT";
export const GET_ACCOUNTS = "GET_ACCOUNTS";
export const ACCOUNTS_LOADING = "ACCOUNTS_LOADING";
export const GET_TRANSACTIONS = "GET_TRANSACTIONS";
export const TRANSACTIONS_LOADING = "TRANSACTIONS_LOADING";